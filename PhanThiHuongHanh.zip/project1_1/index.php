<?php
session_start();
require_once('controller/main_controller.php');
?>