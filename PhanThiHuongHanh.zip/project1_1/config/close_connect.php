<?php
require_once('connect.php');
mysqli_close($connect);
?>