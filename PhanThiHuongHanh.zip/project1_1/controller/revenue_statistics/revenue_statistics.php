<?php
    switch($action){
        case '':
            require_once('model/revenue_statistics/revenue_statistics_model.php');
            require_once('views/revenue_statistics/main.php');
            ;break;
          
    }
?>