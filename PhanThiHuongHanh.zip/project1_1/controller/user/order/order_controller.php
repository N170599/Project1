<?php
    switch($action){
        case '':
            require_once('model/user/order/order_model.php');
            require_once('views/user/order/main.php');
        }
?>