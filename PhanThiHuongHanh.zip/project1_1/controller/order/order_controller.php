<?php
    switch($action){
        case '':
            require_once('model/order/order_model.php');
            require_once('views/order/main.php');
        }
?>