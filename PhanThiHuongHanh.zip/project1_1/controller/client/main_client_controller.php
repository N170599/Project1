<?php
$redirect = $_GET['redirect']??'';
require_once('model/client/index_model.php');
require_once('views/client/interface.php');
?>