<?php
    session_start();
    $_SESSION['number'] = 10;
?>