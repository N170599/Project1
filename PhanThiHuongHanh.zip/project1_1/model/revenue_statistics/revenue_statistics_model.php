<?php
function index(){

}



/*Trả về index cho controller */
switch($action){
    case '': $record = index(); break;
}
?>